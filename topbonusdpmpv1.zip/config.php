<?

$db=mysqli_connect('localhost','getsellw_topb','Mk$786143','getsellw_topb');

if(!$db){echo "many files crupted thats effects on all other files with viruses (your system crashed soon) Other wise deletedthis files"; }


//$payeeracno = 'P1038065239';
$payeeracno = 'P1041386880';
$payeeraccno = 'P1041386880';
$apiIdset =  1641058639;
$apikeyp =  '0nY366yhY8SV4Gr0';
////////////for pmw
$memofpm = 'shop';
$accidfpm = 96429941;
$paspraph = 'Nh0000';
//////////
$pmseckey ='x3p720T9hCbHATpSLTzgSAEKX';
 $mycompany_msg = 'shop';
 $yourpmacc_no = 'U38046502';
 /* for localhost
 $status_url = 'http://localhost:8000/home.php';
 $success_url ='http://localhost:8000/home.php';
 $fail_url = 'http://localhost:8000/home.php';
 */
 
 $status_url = 'https://topbonuss.tk/home.php';
 $success_url ='https://topbonuss.tk/home.php';
 $fail_url = 'https://topbonuss.tk/home.php';
 
/////////////////start of sels page
$orignalval = 107;
$sellvalue = 10;
$slstatus_url = 'https://topbonuss.tk/sells/index.php';
$slsuccess_url = 'https://topbonuss.tk/sells/index.php';
$slsfail_url = 'https://topbonuss.tk/sells/index.php';
$iframeweblink = 'https://topbonuss.tk';
$webslsdemoname = 'Top_Earn';
?>